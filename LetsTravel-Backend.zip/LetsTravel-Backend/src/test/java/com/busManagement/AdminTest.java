package com.busManagement;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import com.busManagement.Dao.AdminDao;
import com.busManagement.Dao.BookingDetailsDao;
import com.busManagement.Dao.BusDetailsDao;
import com.busManagement.Dao.PassengerDao;
import com.busManagement.Dao.UserDao;
import com.busManagement.entity.Admin;
import com.busManagement.serviceImpl.AdminServiceImpl;
import com.busManagement.utils.AdminAuth;


@SpringBootTest
public class AdminTest {

    @Mock
    private AdminDao adminDao;

    @Mock
    private BusDetailsDao busDetailsDao;

    @Mock
    private PassengerDao passengerDao;

    @Mock
    private BookingDetailsDao bookingDao;

    @Mock
    private UserDao userDao;

    @InjectMocks
    private AdminServiceImpl adminService;

    public AdminTest() {
        MockitoAnnotations.openMocks(this);
    }

    // Test for addAdmin method
    @Test
    public void testAddAdmin() {
        Admin admin = new Admin(1, "password", "AdminName");

        when(adminDao.findById(admin.getAdminId())).thenReturn(Optional.empty());
        when(adminDao.save(admin)).thenReturn(admin);

        Admin result = adminService.addAdmin(admin);

        assertNotNull(result);
        assertEquals(admin.getAdminId(), result.getAdminId());
        assertEquals(admin.getAdminName(), result.getAdminName());
        assertEquals(admin.getPassword(), result.getPassword());

        verify(adminDao, times(1)).findById(admin.getAdminId());
        verify(adminDao, times(1)).save(admin);
    }
 // Test for getAdmin method
    @Test
    public void testGetAdmin() {
        Admin admin = new Admin(1, "password", "AdminName");

        when(adminDao.findById(admin.getAdminId())).thenReturn(Optional.of(admin));

        Admin result = adminService.getAdmin(admin.getAdminId());

        assertNotNull(result);
        assertEquals(admin.getAdminId(), result.getAdminId());
        assertEquals(admin.getAdminName(), result.getAdminName());
        assertEquals(admin.getPassword(), result.getPassword());

        verify(adminDao, times(1)).findById(admin.getAdminId());
    }

    
    // Test for deleteAdmin method
    @Test
    public void testDeleteAdmin() {
        Admin admin = new Admin(1, "password", "AdminName");

        when(adminDao.findById(admin.getAdminId())).thenReturn(Optional.of(admin));

        adminService.deleteAdmin(admin.getAdminId());

        verify(adminDao, times(1)).findById(admin.getAdminId());
        verify(adminDao, times(1)).deleteById(admin.getAdminId());
    }
    
 
}

