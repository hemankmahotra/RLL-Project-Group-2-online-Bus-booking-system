package com.busManagement;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import com.busManagement.Dao.UserDao;
import com.busManagement.entity.User;
import com.busManagement.exception.NullUserException;
import com.busManagement.exception.UserDoesnotExistException;
import com.busManagement.serviceImpl.UserServiceImpl;
import com.busManagement.utils.UserAuth;

@SpringBootTest
public class UserTest {

    @Mock
    private UserDao userDao;

    @InjectMocks
    private UserServiceImpl userService;

    public UserTest() {
        MockitoAnnotations.openMocks(this);
    }

    // Test for addUser method
    @Test
    public void testAddUser() {
        User user = new User(/* provide necessary details */);

        when(userDao.findById(user.getUserId())).thenReturn(Optional.empty());
        when(userDao.save(user)).thenReturn(user);

        User result = userService.addUser(user);

        assertNotNull(result);
        assertEquals(user.getUserId(), result.getUserId());

        verify(userDao, times(1)).findById(user.getUserId());
        verify(userDao, times(1)).save(user);
    }

    // Test for updateUser method
    @Test
    public void testUpdateUser() {
        User user = new User(/* provide necessary details */);

        when(userDao.findById(user.getUserId())).thenReturn(Optional.of(user));
        when(userDao.save(user)).thenReturn(user);

        User result = userService.updateUser(user);

        assertNotNull(result);
        assertEquals(user.getUserId(), result.getUserId());

        verify(userDao, times(1)).findById(user.getUserId());
        verify(userDao, times(1)).save(user);
    }

    // Test for getUser method
   


    @Test
    public void testGetUser() {
        Integer userId = 920;
        User user = new User(/* provide necessary details for an existing user */);

        // Assume userDao.findById(userId) returns the user
        when(userDao.findById(userId)).thenReturn(Optional.of(user));

        // Now, invoke the getUser method
        User result = userService.getUser(userId);

        // Assert that the result is not null and is the same user instance
        assertNotNull(result);
        assertEquals(user, result);

        // Verify that findById was called
        verify(userDao, times(1)).findById(userId);
    }

    


    
    @Test
    public void testUserLoginNotFound() {
        UserAuth auth = new UserAuth(/* provide necessary details for a non-existing user */);

        when(userDao.findById(auth.getUserId())).thenReturn(Optional.empty());

        assertThrows(UserDoesnotExistException.class, () -> userService.userLogin(auth));

        verify(userDao, times(1)).findById(auth.getUserId());
    }

    // Add more test cases for other methods if needed
}
