package com.busManagement.utils;

import org.springframework.stereotype.Component;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Component
@Data
@NoArgsConstructor 
@AllArgsConstructor
public class UserAuth {

    private Integer userId;
    private String password;

    // You don't need to manually define getters if you're using Lombok's @Data annotation.
    // Lombok will automatically generate getters for all fields.

    // If you still want to define your own custom getters, you can do it like this:

    // Custom getter for userId
    public Integer getUserId() {
        return this.userId;
    }

    // Custom getter for password
    public String getPassword() {
        return this.password;
    }
}
